package com.example.frosttrident;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class FrostTrident implements ModInitializer {

    // --- Tweak these ---
    private static final int FROST_RADIUS = 2;        // Frost Walker disk radius
    private static final int WALL_HALF_WIDTH = 2;     // wall is (2*this + 1) wide
    private static final int WALL_HEIGHT = 3;
    private static final int WALL_DISTANCE = 2;       // blocks in front of the player
    private static final int WALL_COOLDOWN_TICKS = 40;
    // true  = sneak + right click makes the wall (normal right click still throws)
    // false = plain right click makes the wall (you can no longer throw the trident)
    private static final boolean REQUIRE_SNEAK = true;

    @Override
    public void onInitialize() {
        // Frost Walker while holding the trident
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                if (holdingTrident(player) && player.isOnGround()) {
                    freezeWater((ServerWorld) player.getEntityWorld(), player.getBlockPos());
                }
            }
        });

        // Ice wall on right click
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (!stack.isOf(Items.TRIDENT)) return ActionResult.PASS;
            if (REQUIRE_SNEAK && !player.isSneaking()) return ActionResult.PASS;
            if (player.getItemCooldownManager().isCoolingDown(stack)) return ActionResult.PASS;

            if (!world.isClient()) {
                placeWall(world, player.getBlockPos(), player.getHorizontalFacing());
                player.getItemCooldownManager().set(stack, WALL_COOLDOWN_TICKS);
            }
            return ActionResult.SUCCESS; // swing arm, and don't start the throw
        });
    }

    private static boolean holdingTrident(ServerPlayerEntity player) {
        return player.getMainHandStack().isOf(Items.TRIDENT)
                || player.getOffHandStack().isOf(Items.TRIDENT);
    }

    // Same idea as vanilla Frost Walker: water source -> frosted ice (melts later)
    private static void freezeWater(ServerWorld world, BlockPos feet) {
        int r = FROST_RADIUS;
        for (BlockPos p : BlockPos.iterate(feet.add(-r, -1, -r), feet.add(r, -1, r))) {
            int dx = p.getX() - feet.getX();
            int dz = p.getZ() - feet.getZ();
            if (dx * dx + dz * dz > r * r + 1) continue;

            BlockState state = world.getBlockState(p);
            if (state.isOf(Blocks.WATER)
                    && state.get(FluidBlock.LEVEL) == 0
                    && world.getBlockState(p.up()).isAir()) {
                BlockState ice = Blocks.FROSTED_ICE.getDefaultState();
                if (ice.canPlaceAt(world, p)) {
                    world.setBlockState(p, ice);
                    world.scheduleBlockTick(p.toImmutable(), Blocks.FROSTED_ICE,
                            MathHelper.nextInt(world.getRandom(), 60, 120));
                }
            }
        }
    }

    private static void placeWall(World world, BlockPos origin, Direction facing) {
        BlockPos center = origin.offset(facing, WALL_DISTANCE);
        Direction side = facing.rotateYClockwise();

        for (int w = -WALL_HALF_WIDTH; w <= WALL_HALF_WIDTH; w++) {
            for (int h = 0; h < WALL_HEIGHT; h++) {
                BlockPos p = center.offset(side, w).up(h);
                BlockState existing = world.getBlockState(p);
                if (existing.isAir() || existing.isReplaceable() || existing.isOf(Blocks.WATER)) {
                    world.setBlockState(p, Blocks.ICE.getDefaultState());
                }
            }
        }
        world.playSound(null, center, SoundEvents.BLOCK_GLASS_PLACE, SoundCategory.PLAYERS, 1.0f, 0.8f);
    }
}
