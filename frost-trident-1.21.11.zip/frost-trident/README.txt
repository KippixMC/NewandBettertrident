Frost Trident (Fabric, Minecraft 1.21.11, Java 21)

PLAYING
1. Install Fabric Loader 0.18.4+ for 1.21.11 with the Fabric installer (fabricmc.net/use).
   It adds a "fabric-loader-1.21.11" profile to the official Minecraft Launcher.
2. Put Fabric API (for 1.21.11) and frost-trident-1.0.0.jar in .minecraft/mods.
3. Pick the Fabric profile in the launcher and press Play.

BUILDING
1. Install JDK 21, open this folder in IntelliJ IDEA, or run: gradle build
   (no wrapper? run "gradle wrapper" once, then ./gradlew build)
2. The jar is build/libs/frost-trident-1.0.0.jar (not the -sources jar).

No Java on your PC? Upload this folder to a new GitHub repo, run the
"Build mod jar" action, and download the frost-trident-jar artifact.
